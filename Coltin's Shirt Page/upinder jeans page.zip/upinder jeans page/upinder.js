
function show1()
{
	console.log("C");
	document.getElementById("divu").style.display = "none";
	
}

function show2()
{
	console.log("C");
	document.getElementById("divu").style.display = "block";
	
}